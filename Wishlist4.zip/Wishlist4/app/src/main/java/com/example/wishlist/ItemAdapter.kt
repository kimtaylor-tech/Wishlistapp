package com.example.wishlist

import android.content.Intent
import android.view.LayoutInflater
import android.net.Uri
import android.view.View
import android.widget.Toast
import android.view.ViewGroup
import android.widget.TextView
import android.content.ActivityNotFoundException
import androidx.recyclerview.widget.RecyclerView

class ItemAdapter(private val items: List<Item>) :
    RecyclerView.Adapter<ItemAdapter.ViewHolder>() {


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTv: TextView = itemView.findViewById(R.id.nameTv)
        val priceTv: TextView = itemView.findViewById(R.id.priceTv)
        val urlTv: TextView = itemView.findViewById(R.id.urlTv)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_row, parent, false)
        return ViewHolder(view)
    }


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.nameTv.text = item.name
        holder.priceTv.text = item.price
        holder.urlTv.text = item.url

        holder.urlTv.setOnClickListener {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(item.url))
                holder.itemView.context.startActivity(browserIntent)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(
                    holder.itemView.context,
                    "Invalid URL for ${item.name}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }


    override fun getItemCount(): Int = items.size
}

