package com.example.wishlist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    private val items = mutableListOf<Item>()
    private lateinit var adapter: ItemAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Grab views with findViewById
        val wishlistRv = findViewById<RecyclerView>(R.id.wishlistRv)
        val addBtn = findViewById<Button>(R.id.addBtn)
        val itemNameEt = findViewById<EditText>(R.id.itemNameEt)
        val itemPriceEt = findViewById<EditText>(R.id.itemPriceEt)
        val itemUrlEt = findViewById<EditText>(R.id.itemUrlEt)


        adapter = ItemAdapter(items)
        wishlistRv.adapter = adapter
        wishlistRv.layoutManager = LinearLayoutManager(this)


        addBtn.setOnClickListener {
            val name = itemNameEt.text.toString()
            val price = itemPriceEt.text.toString()
            val url = itemUrlEt.text.toString()

            if (name.isNotEmpty() && price.isNotEmpty() && url.isNotEmpty()) {
                val newItem = Item(name, price, url)
                items.add(newItem)
                adapter.notifyItemInserted(items.size - 1)


                itemNameEt.text.clear()
                itemPriceEt.text.clear()
                itemUrlEt.text.clear()
            }
        }
    }
}

